"""
FastAPI Web Server — accepts prompts, returns compiled app configs
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
import json

from pipeline.orchestrator import AppCompiler

app = FastAPI(title="AppCompiler API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files for frontend
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")


class CompileRequest(BaseModel):
    prompt: str
    api_key: str = None


class CompileResponse(BaseModel):
    status: str
    output: dict
    metrics: dict


@app.get("/")
async def root():
    if os.path.exists("static/index.html"):
        return FileResponse("static/index.html")
    return {"message": "AppCompiler API is running. POST to /compile"}


@app.post("/compile")
async def compile_app(request: CompileRequest):
    api_key = request.api_key or os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise HTTPException(status_code=400, detail="API key required")

    compiler = AppCompiler(api_key)
    result = compiler.compile(request.prompt)

    meta = result.pop("_meta", {})
    return CompileResponse(
        status=meta.get("status", "unknown"),
        output=result,
        metrics=meta.get("metrics", {})
    )


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/sample")
async def sample():
    """Returns a sample compiled output for demo purposes."""
    with open("evaluation/sample_output.json", "r") as f:
        return json.load(f)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
