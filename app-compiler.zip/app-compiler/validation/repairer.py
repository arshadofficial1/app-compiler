"""
Schema Repairer — intelligent targeted repair, not blind retry
"""

import json
import anthropic


class SchemaRepairer:
    def __init__(self, client: anthropic.Anthropic):
        self.client = client

    def repair(self, schema: dict, errors: list) -> dict:
        """Repair only the broken parts, not the full schema."""
        error_summary = "\n".join(f"- {e}" for e in errors)

        response = self.client.messages.create(
            model="claude-opus-4-5",
            max_tokens=4000,
            system="""You are a schema repair engine for an app compiler.
You receive a broken schema and a list of specific errors.
Fix ONLY the identified errors. Do not change what is already correct.
ALWAYS respond with valid JSON only. No markdown, no explanation.
Return the complete repaired schema.""",
            messages=[{
                "role": "user",
                "content": f"""Fix these specific errors in the schema:

ERRORS:
{error_summary}

CURRENT SCHEMA:
{json.dumps(schema, indent=2)}

Return the complete fixed schema as valid JSON."""
            }]
        )

        raw = response.content[0].text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]

        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            # If repair itself failed, return original with error noted
            schema["_repair_failed"] = True
            return schema
