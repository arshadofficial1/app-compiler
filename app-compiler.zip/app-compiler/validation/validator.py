"""
Schema Validator — detects errors across all schema layers
"""


class SchemaValidator:
    def validate(self, schema: dict) -> tuple[bool, list]:
        errors = []

        if not isinstance(schema, dict):
            return False, ["Output is not a valid JSON object"]

        # Check required top-level keys
        required_keys = ["db_schema", "api_schema", "ui_schema", "auth_schema"]
        for key in required_keys:
            if key not in schema:
                errors.append(f"Missing required key: {key}")

        if errors:
            return False, errors

        # Validate DB schema
        errors += self._validate_db(schema.get("db_schema", {}))

        # Validate API schema
        errors += self._validate_api(schema.get("api_schema", {}))

        # Validate UI schema
        errors += self._validate_ui(schema.get("ui_schema", {}))

        # Validate Auth schema
        errors += self._validate_auth(schema.get("auth_schema", {}))

        # Cross-layer consistency
        errors += self._validate_cross_layer(schema)

        return len(errors) == 0, errors

    def _validate_db(self, db: dict) -> list:
        errors = []
        if "tables" not in db:
            errors.append("db_schema: missing 'tables'")
            return errors
        for table in db["tables"]:
            if "name" not in table:
                errors.append("db_schema: table missing 'name'")
            if "columns" not in table or not table["columns"]:
                errors.append(f"db_schema: table '{table.get('name', '?')}' has no columns")
        return errors

    def _validate_api(self, api: dict) -> list:
        errors = []
        if "endpoints" not in api:
            errors.append("api_schema: missing 'endpoints'")
            return errors
        for ep in api["endpoints"]:
            if "path" not in ep:
                errors.append("api_schema: endpoint missing 'path'")
            if "method" not in ep:
                errors.append("api_schema: endpoint missing 'method'")
            if ep.get("method") not in ["GET", "POST", "PUT", "DELETE", "PATCH"]:
                errors.append(f"api_schema: invalid method '{ep.get('method')}'")
        return errors

    def _validate_ui(self, ui: dict) -> list:
        errors = []
        if "pages" not in ui:
            errors.append("ui_schema: missing 'pages'")
        return errors

    def _validate_auth(self, auth: dict) -> list:
        errors = []
        if "roles" not in auth:
            errors.append("auth_schema: missing 'roles'")
        if "strategy" not in auth:
            errors.append("auth_schema: missing 'strategy'")
        return errors

    def _validate_cross_layer(self, schema: dict) -> list:
        """Check consistency between layers."""
        errors = []
        try:
            db_tables = {t["name"] for t in schema["db_schema"].get("tables", [])}
            auth_roles = {r["name"] for r in schema["auth_schema"].get("roles", [])}
            api_roles = set()
            for ep in schema["api_schema"].get("endpoints", []):
                api_roles.update(ep.get("roles", []))

            # API should not reference roles that don't exist in auth
            unknown_roles = api_roles - auth_roles
            if unknown_roles:
                errors.append(f"cross_layer: API references unknown roles: {unknown_roles}")

        except Exception as e:
            errors.append(f"cross_layer validation error: {str(e)}")

        return errors
