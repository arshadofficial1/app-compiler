# AppCompiler 🔧

**Natural Language → Structured Config → Executable App**

A multi-stage compiler that transforms plain English app descriptions into strict, validated, production-ready configuration schemas.

---

## Architecture Overview

```
User Prompt
    ↓
[Stage 1] Intent Extraction      → Parses goals, roles, features
    ↓
[Stage 2] System Design          → Entities, flows, pages, permissions
    ↓
[Stage 3] Schema Generation      → DB + API + UI + Auth schemas
    ↓
[Stage 4] Refinement             → Cross-layer consistency resolution
    ↓
[Validation + Repair Engine]     → Detects & fixes errors automatically
    ↓
Validated JSON Output
```

## Why Multi-Stage?

A single prompt approach fails because:
- LLMs hallucinate fields and relationships at scale
- No way to validate intermediate consistency
- Can't repair specific broken parts — must retry everything
- No control over output structure

Our pipeline fixes this: each stage has a **strict contract**, output is **validated per-stage**, and repair is **targeted** (not blind retry).

---

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/arshadofficial1/app-compiler.git
cd app-compiler

# 2. Install dependencies
pip install -r requirements.txt

# 3. Add your API key
cp .env.example .env
# Edit .env and add your Anthropic API key

# 4. Run the server
python server.py
# Open http://localhost:8000
```

---

## Usage

### Web Interface
Open `http://localhost:8000` → Enter a prompt → Click Compile

### API
```bash
curl -X POST http://localhost:8000/compile \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Build a CRM with login, contacts, dashboard, and analytics",
    "api_key": "sk-ant-..."
  }'
```

### Python
```python
from pipeline.orchestrator import AppCompiler

compiler = AppCompiler(api_key="sk-ant-...")
result = compiler.compile("Build a blog platform with auth and comments")
print(result)
```

---

## Output Schema

Every compilation produces:

```json
{
  "db_schema": {
    "tables": [{ "name": "...", "columns": [...] }]
  },
  "api_schema": {
    "base_url": "/api/v1",
    "endpoints": [{ "path": "...", "method": "GET", "auth_required": true }]
  },
  "ui_schema": {
    "theme": { "primary": "#hex" },
    "pages": [{ "name": "...", "components": [...] }]
  },
  "auth_schema": {
    "strategy": "jwt",
    "roles": [{ "name": "admin", "can_access": [...] }]
  },
  "consistency_report": ["list of fixes applied"],
  "_meta": {
    "status": "success",
    "metrics": { "latency": 12.4, "retries": 0, "stages_completed": [...] }
  }
}
```

---

## Validation + Repair Engine

The validator checks:
- ✅ Valid JSON structure
- ✅ All required schema keys present
- ✅ DB tables have columns
- ✅ API methods are valid HTTP verbs
- ✅ Auth roles are consistent across API + auth schema
- ✅ Cross-layer consistency (UI → API → DB)

If errors are found → the **Repairer** fixes only the broken parts using targeted prompting. No full retry.

---

## Evaluation

Run the evaluation framework:
```bash
python -m evaluation.eval_runner
```

Tests 20 prompts (10 real products + 10 edge cases: vague, conflicting, incomplete).

Tracks: success rate, retries per request, failure types, latency.

---

## Cost vs Quality Tradeoffs

| Strategy | Latency | Cost | Quality |
|----------|---------|------|---------|
| Single prompt | ~3s | Low | Poor (inconsistent) |
| 4-stage pipeline | ~15-25s | Medium | High (consistent) |
| 4-stage + repair | ~20-35s | Medium+ | Very High |

We chose quality over speed because **unusable fast output is worse than reliable slow output**.

---

## Project Structure

```
app-compiler/
├── pipeline/
│   ├── orchestrator.py    # Main compiler entry point
│   └── stages.py          # 4 isolated pipeline stages
├── validation/
│   ├── validator.py       # Schema validation engine
│   └── repairer.py        # Targeted repair engine
├── evaluation/
│   └── eval_runner.py     # 20-prompt evaluation framework
├── static/
│   └── index.html         # Web interface
├── server.py              # FastAPI web server
├── requirements.txt
└── README.md
```

---

Built by **arshadofficial1** · Demo Task for AI Platform Engineer (Founding Intern)
