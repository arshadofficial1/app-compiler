"""
AppCompiler Pipeline Orchestrator
Multi-stage natural language → app config compiler
"""

import json
import time
import anthropic
from pipeline.stages import IntentExtractor, SystemDesigner, SchemaGenerator, Refiner
from validation.validator import SchemaValidator
from validation.repairer import SchemaRepairer


class AppCompiler:
    def __init__(self, api_key: str):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.validator = SchemaValidator()
        self.repairer = SchemaRepairer(self.client)
        self.metrics = {
            "retries": 0,
            "failures": [],
            "latency": 0,
            "stages_completed": []
        }

    def compile(self, user_prompt: str) -> dict:
        start_time = time.time()
        self.metrics = {"retries": 0, "failures": [], "latency": 0, "stages_completed": []}

        try:
            # Stage 1: Intent Extraction
            print("[Stage 1] Extracting intent...")
            intent = IntentExtractor(self.client).run(user_prompt)
            self.metrics["stages_completed"].append("intent_extraction")

            # Stage 2: System Design
            print("[Stage 2] Designing system architecture...")
            architecture = SystemDesigner(self.client).run(intent)
            self.metrics["stages_completed"].append("system_design")

            # Stage 3: Schema Generation
            print("[Stage 3] Generating schemas...")
            schemas = SchemaGenerator(self.client).run(architecture)
            self.metrics["stages_completed"].append("schema_generation")

            # Stage 4: Refinement
            print("[Stage 4] Refining and resolving inconsistencies...")
            refined = Refiner(self.client).run(schemas)
            self.metrics["stages_completed"].append("refinement")

            # Validation + Repair Loop
            print("[Validation] Validating output...")
            max_repair_attempts = 3
            for attempt in range(max_repair_attempts):
                is_valid, errors = self.validator.validate(refined)
                if is_valid:
                    break
                print(f"[Repair] Attempt {attempt + 1}: fixing {len(errors)} errors...")
                self.metrics["retries"] += 1
                refined = self.repairer.repair(refined, errors)

            self.metrics["latency"] = round(time.time() - start_time, 2)
            refined["_meta"] = {
                "prompt": user_prompt,
                "metrics": self.metrics,
                "status": "success"
            }
            return refined

        except Exception as e:
            self.metrics["failures"].append(str(e))
            self.metrics["latency"] = round(time.time() - start_time, 2)
            return {
                "_meta": {
                    "prompt": user_prompt,
                    "metrics": self.metrics,
                    "status": "failed",
                    "error": str(e)
                }
            }
