"""
Pipeline Stages: Intent → Architecture → Schema → Refinement
Each stage is isolated, testable, and deterministic
"""

import json
import anthropic


def call_claude(client: anthropic.Anthropic, system: str, user: str) -> dict:
    """Call Claude and parse JSON response reliably."""
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=4000,
        system=system,
        messages=[{"role": "user", "content": user}]
    )
    raw = response.content[0].text.strip()
    # Strip markdown fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw.strip())


class IntentExtractor:
    """Stage 1: Parse natural language into structured intent."""

    SYSTEM = """You are an intent extraction engine for an app compiler.
Extract structured intent from user descriptions.
ALWAYS respond with valid JSON only. No markdown, no explanation.
Output format:
{
  "app_name": "string",
  "app_type": "string (crm|ecommerce|saas|dashboard|marketplace|other)",
  "core_features": ["list of features"],
  "user_roles": ["list of roles"],
  "auth_required": true/false,
  "payment_required": true/false,
  "assumptions": ["list of reasonable assumptions made"],
  "clarifications_needed": ["list of ambiguous items handled with defaults"]
}"""

    def __init__(self, client):
        self.client = client

    def run(self, prompt: str) -> dict:
        return call_claude(
            self.client,
            self.SYSTEM,
            f"Extract intent from this app description:\n\n{prompt}"
        )


class SystemDesigner:
    """Stage 2: Convert intent into system architecture."""

    SYSTEM = """You are a system architect for an app compiler.
Convert structured intent into a full system architecture.
ALWAYS respond with valid JSON only. No markdown, no explanation.
Output format:
{
  "entities": [{"name": "string", "description": "string", "fields": ["field1", "field2"]}],
  "user_flows": [{"name": "string", "steps": ["step1", "step2"]}],
  "roles": [{"name": "string", "permissions": ["perm1", "perm2"]}],
  "pages": [{"name": "string", "route": "string", "access": "string", "components": ["comp1"]}],
  "integrations": ["payment", "email", "etc"]
}"""

    def __init__(self, client):
        self.client = client

    def run(self, intent: dict) -> dict:
        return call_claude(
            self.client,
            self.SYSTEM,
            f"Design system architecture for this intent:\n\n{json.dumps(intent, indent=2)}"
        )


class SchemaGenerator:
    """Stage 3: Generate all schemas from architecture."""

    SYSTEM = """You are a schema generator for an app compiler.
Generate complete, consistent schemas from system architecture.
ALWAYS respond with valid JSON only. No markdown, no explanation.
Output format:
{
  "db_schema": {
    "tables": [{"name": "string", "columns": [{"name": "string", "type": "string", "nullable": false, "primary_key": false, "foreign_key": null}], "indexes": []}]
  },
  "api_schema": {
    "base_url": "/api/v1",
    "endpoints": [{"path": "string", "method": "GET|POST|PUT|DELETE", "auth_required": true, "roles": [], "request_body": {}, "response": {}, "description": "string"}]
  },
  "ui_schema": {
    "theme": {"primary": "#hex", "secondary": "#hex", "font": "string"},
    "pages": [{"name": "string", "route": "string", "layout": "string", "components": [{"type": "string", "props": {}, "data_source": "string"}]}]
  },
  "auth_schema": {
    "strategy": "jwt|session|oauth",
    "roles": [{"name": "string", "can_access": [], "cannot_access": []}],
    "endpoints": {"login": "string", "logout": "string", "register": "string", "refresh": "string"}
  }
}"""

    def __init__(self, client):
        self.client = client

    def run(self, architecture: dict) -> dict:
        return call_claude(
            self.client,
            self.SYSTEM,
            f"Generate all schemas for this architecture:\n\n{json.dumps(architecture, indent=2)}"
        )


class Refiner:
    """Stage 4: Resolve cross-layer inconsistencies."""

    SYSTEM = """You are a consistency checker and refiner for an app compiler.
Review all schemas and resolve any inconsistencies:
- API fields must match DB schema
- UI fields must map to API endpoints
- Auth roles must be consistent across all layers
- All referenced tables/endpoints must exist

ALWAYS respond with valid JSON only. No markdown, no explanation.
Return the corrected, complete schema in the same format as input.
Add a "consistency_report" field at the root level listing what was fixed."""

    def __init__(self, client):
        self.client = client

    def run(self, schemas: dict) -> dict:
        return call_claude(
            self.client,
            self.SYSTEM,
            f"Review and refine these schemas for consistency:\n\n{json.dumps(schemas, indent=2)}"
        )
