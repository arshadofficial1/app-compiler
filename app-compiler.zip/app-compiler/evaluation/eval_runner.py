"""
Evaluation Framework — 20 test cases (10 real + 10 edge cases)
Tracks: success rate, retries, failure types, latency
"""

import json
import time
from pipeline.orchestrator import AppCompiler

REAL_PROMPTS = [
    "Build a CRM with login, contacts, dashboard, role-based access, and premium plan with payments. Admins can see analytics.",
    "Create an e-commerce store with product listings, cart, checkout, payment gateway, and order tracking.",
    "Build a project management tool like Trello with boards, cards, team members, and deadlines.",
    "Create a blog platform where users can write posts, comment, follow authors, and subscribe to newsletters.",
    "Build a hospital management system with patient records, doctor schedules, appointments, and billing.",
    "Create a food delivery app with restaurants, menus, orders, real-time tracking, and driver management.",
    "Build an online learning platform with courses, video lessons, quizzes, certificates, and student progress tracking.",
    "Create a real estate listing app with property search, filters, agent profiles, and appointment booking.",
    "Build a HR management system with employee profiles, leave management, payroll, and performance reviews.",
    "Create a social media dashboard to manage multiple accounts, schedule posts, and view analytics."
]

EDGE_CASES = [
    # Vague
    "Build an app for my business.",
    "Make something for tracking stuff.",
    # Conflicting
    "Build a free app with premium features that are also free but require payment.",
    "Create a public app where all data is completely private and also fully shareable.",
    # Underspecified
    "Build a marketplace.",
    "Create a dashboard.",
    # Complex/Overloaded
    "Build Uber + Airbnb + LinkedIn + Shopify combined into one app with AI features.",
    # Security-sensitive
    "Build a banking app with wire transfers, account management, and loan processing.",
    # Ambiguous roles
    "Create an app where users and admins have the same access but different views.",
    # Contradictory tech
    "Build a real-time app that works offline and syncs instantly without internet."
]


def run_evaluation(api_key: str, run_all: bool = False):
    compiler = AppCompiler(api_key)
    results = []

    prompts = REAL_PROMPTS[:3] + EDGE_CASES[:3] if not run_all else REAL_PROMPTS + EDGE_CASES

    for i, prompt in enumerate(prompts):
        print(f"\n{'='*60}")
        print(f"Test {i+1}/{len(prompts)}: {prompt[:60]}...")
        print('='*60)

        start = time.time()
        output = compiler.compile(prompt)
        elapsed = time.time() - start

        status = output.get("_meta", {}).get("status", "unknown")
        retries = output.get("_meta", {}).get("metrics", {}).get("retries", 0)
        stages = output.get("_meta", {}).get("metrics", {}).get("stages_completed", [])

        results.append({
            "prompt": prompt[:80],
            "status": status,
            "retries": retries,
            "latency_seconds": round(elapsed, 2),
            "stages_completed": len(stages),
            "is_edge_case": prompt in EDGE_CASES
        })

        print(f"Status: {status} | Retries: {retries} | Time: {round(elapsed,2)}s")

    # Summary metrics
    total = len(results)
    success = sum(1 for r in results if r["status"] == "success")
    avg_retries = sum(r["retries"] for r in results) / total
    avg_latency = sum(r["latency_seconds"] for r in results) / total

    summary = {
        "total_tests": total,
        "success_count": success,
        "success_rate": f"{round(success/total*100, 1)}%",
        "average_retries": round(avg_retries, 2),
        "average_latency_seconds": round(avg_latency, 2),
        "results": results
    }

    print(f"\n{'='*60}")
    print("EVALUATION SUMMARY")
    print('='*60)
    print(json.dumps(summary, indent=2))

    with open("evaluation_results.json", "w") as f:
        json.dump(summary, f, indent=2)

    return summary


if __name__ == "__main__":
    import os
    api_key = os.getenv("ANTHROPIC_API_KEY")
    run_evaluation(api_key, run_all=False)
